<?php session_start(); ?>
<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>5C Menu Login</title>

    <!-- Bootstrap Core CSS -->
    <link href="css/bootstrap.min.css" rel="stylesheet">

    <!-- Custom CSS -->
    <link href="css/shop-homepage.css" rel="stylesheet">
    <link href="css/our.css" rel="stylesheet">
    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
        <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->
    
    <!-- validate -->
    <script src="bootstrap/js/5Cvalidate.js"></script>
    <!-- jQuery -->
    <script src="bootstrap/js/jquery.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="bootstrap/js/bootstrap.min.js"></script>
 

</head>

<body>

    <!-- Navigation -->
    <nav class="navbar navbar-inverse navbar-fixed-top">
        <div class="center">
        <div class="container">
            <!-- Brand and toggle get grouped for better mobile display -->
            <div class="navbar-header"> 
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
        
                <a class="navbar-brand-custom" href="#">Welcome to the 5C Menu</a>
        <!-- /.container -->
    </nav>

    <!-- Page Content -->
    <div class="center">
    <div class="container">

    <h3>uh oh.. Something didn't match! Check your name and password again.</h3>

    <?php 

        if ( isset($_GET["submit"]) ) 
        {
            $host = "localhost"; 
            $username = "root"; 
            $password = "root"; 
            $database = "Menu"; 
            $fname = $_GET['fname']; 
            $lname = $_GET['lname'];
            $pass = $_GET['password'];

            $conn = mysqli_connect("$host", "$username", "$password", "$database"); 

            if (!$conn){
                die("Connection Failed: " . mysqli_connect_error()); 
            }
            echo "Connected Successfully" . "<br>";
            
            $exists = "SELECT * FROM Students WHERE fname = '$fname' AND lname = '$lname'";
            $checkExists = mysqli_query($conn, $exists); 
            $existsNum = mysqli_num_rows($checkExists); 

            if($existsNum > 0) {
                echo "in"; 
               
                $_SESSION['userFname'] = $fname;
                $userLname = $lname;
                $userPass = $pass;
                //header("Location: items.php"); 
            }

            else {
                //header("Location: mistake.php"); 
            } 

            
           //window.location = "public/items.php";
            
        }
        else {

            echo ' <div class="row">
            <form method="get" >
            <div class="col-md-3">
                <p align="center" class="lead-custom">Login</p>
                <div class="list-group">
                    <legend>First Name:
                    <input type="text" id="fname" class="list-group-item" name="fname" value="" onblur="showValidation("name", this, "tb1")"></input><span id="tb1"> </span></legend>
                    <legend>Last Name:
                    <input type="text" id="lname" class="list-group-item" name="lname" value="" onblur="showValidation("name", this, "tb2")"></input><span id="tb2"> </span</legend>
                    <legend>Password:
                    <input type="password" id="password" class="list-group-item" name="password" value="" onblur="showValidation("password", this, "tb3")"></input><span id="tb3"> </span></legend>
                    <input id="submit" class="list-group-item" type="submit" value="Login" name="submit"></input>
                    
                </div>
                <a href="newuser.php">New User? Click here to sign up </a>
            </div>
            </form>
        </div>';


        }

    ?>



       


    </div>
    </div>
    <!-- /.container -->

    <div class="container">

        <hr>

        <!-- Footer -->
        <footer>
            <div class="row">
                <div class="col-lg-12">
                    <p>Copyright 5C Menu 2017 | TC Solutions</p>
                </div>
            </div>
        </footer>

    </div>
    <!-- /.container -->

    


</body>

</html>