<script type="text/javascript">
function showValidation (type, elem, spanID){
	if (validate(type, elem)) {
		document.getElementById(spanID).innerHTML = "OK";
	}
	else {
		document.getElementById(spanID).innerHTML = "Invalid";
	}

};
function validate(type, elem) {
	if (type == "name") {
		var usernameRegex = /[a-z0-9.]$/;
		var test = $(elem).val();
		if (usernameRegex.test(test)) {
			return true;
		}
		else {
			return false;
		}
	}
	
	if (type == "password") {
		var passRegex = /[a-z0-9]{8}$/;
		var alsoo = /[0-9]{1,1}$/;
		if (passRegex.test($(elem).val())) {
			if (alsoo.test($(elem).val())) {
				return true;
			}
		}
		else {
			return false;
		}
	}
};
function insertDB(){
	console.log("inside insertDB");
	<?php 
	$host = "localhost"; 
	$username = "root"; 
	$password = "root"; 
	$database = "Menu"; 
	$fname = $GET_['fname']; 
	$lname = $GET_['lname'];
	$pass = $GET_['password'];

	$conn = mysqli_connect("$host", "$username", "$password", "$database"); 

	if (!$conn){
		die("Connection Failed: " . mysqli_connect_error()); 
	}
		echo "Connected Successfully" . "<br>";
	?>

	$sql = "INSERT INTO Students (fname, lname, password) VALUES ('$fname', '$lname', '$password')"; 
		if ($conn->query($sql) === TRUE) {
    		echo "New record created successfully";
		} else {
    		echo "Error: " . $sql . "<br>" . $conn->error;
		} 

};
</script>