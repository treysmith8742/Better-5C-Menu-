DROP DATABASE IF EXISTS MENU; 

CREATE DATABASE MENU; 

USE MENU;

CREATE TABLE Favorites (
  student_fk int(10) UNSIGNED NOT NULL,
  name varchar(256) NOT NULL,
  description varchar(256) DEFAULT NULL,
  spot varchar(256) DEFAULT NULL,
  hall varchar(256) NOT NULL,
  meal varchar(256) NOT NULL
); 

-- --------------------------------------------------------

--
-- Table structure for table `Items`
--

CREATE TABLE Items (
  item_id int(10) UNSIGNED NOT NULL,
  name varchar(256) NOT NULL,
  description varchar(256) DEFAULT NULL,
  spot varchar(256) DEFAULT NULL,
  hall varchar(256) NOT NULL,
  meal varchar(256) NOT NULL
); 

-- --------------------------------------------------------

--
-- Table structure for table `Students`
--

CREATE TABLE Students (
  student_id int(10) UNSIGNED NOT NULL,
  fname varchar(256) NOT NULL,
  lname varchar(256) NOT NULL,
  password varchar(256) NOT NULL
); 