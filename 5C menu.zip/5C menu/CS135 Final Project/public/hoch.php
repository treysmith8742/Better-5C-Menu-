<!DOCTYPE html>

<?php 
    session_start();
 ?>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>5C Menu</title>

    <!-- Bootstrap Core CSS -->
    <link href="css/bootstrap.min.css" rel="stylesheet">

    <!-- Custom CSS -->
    <link href="css/shop-homepage.css" rel="stylesheet">
    <link href="css/our.css" rel="stylesheet">

    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
        <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->

</head>

<body>



    <!-- Navigation -->
    <nav class="navbar navbar-inverse navbar-fixed-top" role="navigation">
        <div class="container">
            <!-- Brand and toggle get grouped for better mobile display -->
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" href="#">5C Menu</a>
            </div>
            <!-- Collect the nav links, forms, and other content for toggling -->
            <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
                <ul class="nav navbar-nav">
                    <li>
                        <a href="#">About</a>
                    </li>
                    <li>
                        <a href="#">Services</a>
                    </li>
                    <li>
                        <a href="#">Contact</a>
                    </li>
                </ul>
            </div>
            <!-- /.navbar-collapse -->
        </div>
        <!-- /.container -->
    </nav>

    <!-- Page Content -->

    <div class="container">

        <div class="row">
            <form method = "get">
            <div class="col-md-3">
                <p class="lead">Dining Halls </p>
                <div class="list-group">
                    <a href="favorites.php" class="list-group-item">Favorites</a>
                    <a href="collins.php" class="list-group-item">Collins</a>
                    <a href="frary.php" class="list-group-item">Pomona (Frary)</a>
                    <a href="pitzer.php" class="list-group-item">Pitzer</a>
                    <a href="hoch.php" class="list-group-item">Harvy Mudd</a>
                    <a href="scripps.php" class="list-group-item">Scripps</a>
                    <a href="frank.php" class="list-group-item">Pomona (Frank)</a>
                    <a href="oldenborg.php" class="list-group-item">Pomona (Oldenborg)</a>
                </div>
            </div>
            </form>
            <div class="col-md-9">

            <table style="width:50%">
                <tr>
                    <th><h3><a href = "#">Breakfast</a></h3></th>
                    <th><h3><a ref = "#">Lunch</a></h3></th>
                    <th><h3><a ref = "#">Dinner</a></h3></th>
                </tr>
            </table>

<!--                 <div class="row carousel-holder">

                    <div class="col-md-12">
                        <div id="carousel-example-generic" class="carousel slide" data-ride="carousel">
                            <ol class="carousel-indicators">
                                <li data-target="#carousel-example-generic" data-slide-to="0" class="active"></li>
                                <li data-target="#carousel-example-generic" data-slide-to="1"></li>
                                <li data-target="#carousel-example-generic" data-slide-to="2"></li>
                            </ol>
                            <div class="carousel-inner">


                                <div class="item active">
                                     
                                </div>
                                <div class="item">
                                    
                                </div>
                                <div class="item">
                                    
                                </div>


                            </div>
                            <a class="left carousel-control" href="#carousel-example-generic" data-slide="prev">
                                <span class="glyphicon glyphicon-chevron-left"></span>
                            </a>
                            <a class="right carousel-control" href="#carousel-example-generic" data-slide="next">
                                <span class="glyphicon glyphicon-chevron-right"></span>
                            </a>
                        </div>
                    </div>

                </div> -->

<?php 
         
        $_SESSION['name'] = 'Trey';  
    if ( isset($_SESSION['name']) ){
        $host = "localhost"; 
        $username = "root"; 
        $password = "root"; 
        $database = "Menu"; 

        $conn = mysqli_connect("$host", "$username", "$password", "$database"); 

        if (!$conn){
        die("Connection Failed: " . mysqli_connect_error()); 
        }
        echo "Connected Successfully" . "<br>";

        $sql = "SELECT * FROM Items WHERE hall = 'hoch' AND meal = 'dinner'"; 
        $result = mysqli_query($conn, $sql); 
        print_r($result);

        echo "<h1> Hoch </h1>";

        echo '<div class="row">'; 


                // TODO -- if statment to check if $_GET array has 'REMOVE'
                // If so, remove from db 
                if( isset($_GET["remove"]))
                    {
                        $mealName = $_GET['name']; 
                        $mealDesc = $_GET['description']; 
                        $mealSpot = $_GET['spot']; 
                        $mealHall = $_GET['hall']; 
                        $meal = $_GET['meal']; 


                        $sqlRem = "DELETE FROM Favorites WHERE name = '$mealName' AND description = '$mealDesc' AND spot = '$mealSpot' AND hall = '$mealHall' AND meal = '$meal'";

                        if ($conn->query($sqlRem) === TRUE) {
                             echo "record added successfully"; 
                
                        } else {
                             echo "Error: " . $sqlRem . "<br>" . $conn->error;
                        }            
                    }


                if( isset($_GET["favorite"]))
                    {
                        $mealName = $_GET['name']; 
                        $mealDesc = $_GET['description']; 
                        $mealSpot = $_GET['spot']; 
                        $mealHall = $_GET['hall']; 
                        $meal = $_GET['meal']; 


                        $sqlFav = "INSERT INTO Favorites (student_fk, name, description, spot, hall, meal) 
                                    VALUES ((SELECT student_id from Students WHERE fname = 'Trey'), '$mealName', '$mealDesc', '$mealSpot', '$mealHall', '$meal')"; 

                        if ($conn->query($sqlFav) === TRUE) {
                             echo "record added successfully"; 
                
                        } else {
                             echo "Error: " . $sqlFav . "<br>" . $conn->error;
                        }            
                    }



        // TODO - Do a select query to grab grab everything from favorites 
         // $checkSQL = "SELECT * FROM Favorites";
         // $checkResult = mysqli_query($conn, $checkSQL);  



        while ($row_items = mysqli_fetch_array($result)){
            $mealName = $row_items['name']; 
            $mealDesc = $row_items['description']; 
            $mealSpot = $row_items['spot']; 
            $mealID = $row_items['item_id']; 
            $mealHall = $row_items['hall']; 
            $meal = $row_items['meal']; 
 





            // TODO - if meanName is in favorites list, then display 'REMOVE' button instead of 'Favorite'
            $checkSQL = "SELECT * FROM Favorites WHERE name = '$mealName' AND description = '$mealDesc' AND spot = '$mealSpot' AND hall = '$mealHall' AND         meal = '$meal'"; 
            $checkResult = mysqli_query($conn, $checkSQL); 
            $checkNum = mysqli_num_rows($checkResult); 
            //print_r($checkResult); 

            if ($checkNum > 0) {
                
                echo '<div class="col-sm-4 col-lg-4 col-md-4">
                        <div class="thumbnail">
                            <div class="caption">
                            <form method = "get">
                                <h4>' . $mealName . '</h4>
                                <input type = "hidden" name = "name" value = "'. $mealName . '">
                                <p>' . $mealDesc . '</p>
                                <input type = "hidden" name = "description" value = "'. $mealDesc . '">
                                <p>' . $mealSpot . '</p> </br>
                                <input type = "hidden" name = "spot" value = "'. $mealSpot . '">
                                <input type = "hidden" name = "hall" value = "'. $mealHall . '">
                                <input type = "hidden" name = "meal" value = "'. $meal . '">

                                <input type = "submit" name = "remove" value = "Remove">
                            </form>
                            </div>
                        </div>
                    </div>';
                
            } else {
                     
                    echo '<div class="col-sm-4 col-lg-4 col-md-4">
                        <div class="thumbnail">
                            <div class="caption">
                            <form method = "get">
                                <h4>' . $mealName . '</h4>
                                <input type = "hidden" name = "name" value = "'. $mealName . '">
                                <p>' . $mealDesc . '</p>
                                <input type = "hidden" name = "description" value = "'. $mealDesc . '">
                                <p>' . $mealSpot . '</p> </br>
                                <input type = "hidden" name = "spot" value = "'. $mealSpot . '">
                                <input type = "hidden" name = "hall" value = "'. $mealHall . '">
                                <input type = "hidden" name = "meal" value = "'. $meal . '">

                                <input type = "submit" name = "favorite" value = "Favorite">
                            </form>
                            </div>
                        </div>
                    </div>';
            }
                  
        }

        echo '</div>'; 

      

        $conn->close();
    }
?>

                <!-- <div class="row">

                    <div class="col-sm-4 col-lg-4 col-md-4">
                        <div class="thumbnail">
                            <img src="http://placehold.it/320x150" alt="">
                            <div class="caption">
                                <h4 class="pull-right">$24.99</h4>
                                <h4><a href="#">First Product</a>
                                </h4>
                                <p>See more snippets like this online store item at <a target="_blank" href="http://www.bootsnipp.com">Bootsnipp - http://bootsnipp.com</a>.</p>
                            </div>
                            <div class="ratings">
                                <p class="pull-right">15 reviews</p>
                                <p>
                                    <span class="glyphicon glyphicon-star"></span>
                                    <span class="glyphicon glyphicon-star"></span>
                                    <span class="glyphicon glyphicon-star"></span>
                                    <span class="glyphicon glyphicon-star"></span>
                                    <span class="glyphicon glyphicon-star"></span>
                                </p>
                            </div>
                        </div>
                    </div>

                    

                </div> -->

            </div>

        </div>

    </div>
    <!-- /.container -->

    <div class="container">

        <hr>

        <!-- Footer -->
        <footer>
            <div class="row">
                <div class="col-lg-12">
                    <p>Copyright 5C Menu 2017 | TC Solutions</p>
                </div>
            </div>
        </footer>

    </div>
    <!-- /.container -->

    <!-- jQuery -->
    <script src="public/js/jquery.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="public/js/bootstrap.min.js"></script>

</body>

</html>